A List of how many of what category will be present:
|Category|Count|```List```| 
| ---------- | - | ----------- |
|Chest|7 / 16| ```Chest, Large Chest, Damage Chest, Healing Chest, Utility Chest, Equipment Barrel, Lunar Pod, Multishop, Large Multishop, Equipment Multishop, Adaptive Chest, Large Damage Chest, Large Healing Chest, Large Utility Chest, Void Cradle, Void Potential```|
|Misc|2 / 4|```Barrel, Void Barrel, Scrappers, Void Camps```|
|Shrines|3 / 8|```Shrine of Chance, Shrine of Blood, Shrine of the Mountain (2x),Shrine of Combat, Shrine of the Woods, Shrine of Order, Cleansing Pool```|
|Drones|3 / 8|```Gunner Drone, Healing Drone, Gunner Turret, Missile Drone, Incinerator Drone, Equipment Drone, Emergency Drone, TC-280 Prototype  ```|
|Printers|4 / 8|```Printer, Large Printer, Mili-Tech Printer, Overgrown Printer, Scrapper, Cauldron WhiteToGreen, Cauldron GreenToRed, Cauldron RedToWhite```|
|Rare|2 / 5|```Legendary Chest, Altar of Gold, Lunar Seer, Cloaked Chest, Void Eradicator```|

